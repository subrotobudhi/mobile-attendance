<?php
require "conn.php";
$keterangan = $_POST["status"];
$id_device = $_POST["id_device"];
//$keterangan = "0";
//$id_device = "d9914a1bf2f48509";
$mysql_qry = "update pegawai set status='$keterangan' where id_device='$id_device'";

if ($conn->query($mysql_qry) === TRUE) {
	echo "Data Berhasil Disimpan....";
}
else {
	echo "ERROR : " . $mysql_qry . "<br>" . $conn->error;
}
$conn->close();
?>