<?php
error_reporting(0);
require "conn.php";
$android_id = $_POST["android_id"];
$mysql_qry = "select * from pegawai where id_device like '$android_id'";
$result = mysqli_query($conn, $mysql_qry);
if (mysqli_num_rows($result)>0) {
	echo "Selamat Datang";
}
else {
	echo "Device Belum Terdaftar";
}
$conn->close();
?>