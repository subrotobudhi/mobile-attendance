<?php
require "conn.php";

$id_device = $_POST["id_device"];
$keterangan = $_POST["keterangan"];
$lat_cek =$_POST["lat_cek"];
$lon_cek = $_POST["lon_cek"];

//$id_device = "d9914a1bf2f48509";
//$keterangan = "Cek In";
//$lat_cek = "-6.8795";
//$lon_cek = "107.612";
date_default_timezone_set('Asia/Jakarta');
$tgl = Date ('Y-m-d');
$jam = Date ('H:i:s');

$mysql_qry = "insert into aktivitas value ('$id_device', '$tgl', '$jam', '$lat_cek', '$lon_cek', '$keterangan')";

if ($conn->query($mysql_qry) === TRUE) {
	echo "Data Berhasil Disimpan....";
}
else {
	echo "ERROR : " . $mysql_qry . "<br>" . $conn->error;
}

$conn->close();
?>