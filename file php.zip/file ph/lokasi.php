<?php
require "conn.php";
error_reporting(0);
$id_device = $_POST["id_device"];
/* $id_device = "d9914a1bf2f48509"; */
$mysql_qry = "select * from pegawai where id_device like '$id_device'";
$result = mysqli_query($conn, $mysql_qry);
if (mysqli_num_rows($result)>0) {
    $row = mysqli_fetch_assoc ($result);
    $id = $id_device;
    $mysql_qry_data = "select * from pegawai where id_device like '$id'";
    $result_data = mysqli_query($conn, $mysql_qry_data);
	$hasil_data = array();

    while ($row = mysqli_fetch_array($result_data)) {
        array_push ($hasil_data, array("id"=>$row[0], "nama_pegawai"=>$row[1], "lat_kantor"=>$row[2], "lon_kantor"=>$row[3], "id_device"=>$row[4], "status"=>$row[5]));
    }

    echo json_encode(array("hasil data"=>$hasil_data));

}
else {
	echo "GAGAL";
}
$conn->close();
?>