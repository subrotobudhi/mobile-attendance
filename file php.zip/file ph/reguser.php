<?php
require "conn.php";
$id_pegawai = $_POST["id_pegawai"];
$id_device = $_POST["id_device"];
$mysql_qry = "update pegawai set id_device='$id_device' where id_pegawai='$id_pegawai'";

if ($conn->query($mysql_qry) === TRUE) {
	echo "Data Berhasil Disimpan....";
}
else {
	echo "ERROR : " . $mysql_qry . "<br>" . $conn->error;
}
$conn->close();
?>