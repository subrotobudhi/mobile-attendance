<?php
require "conn.php";
error_reporting(0);
$id_pegawai = $_POST["id_pegawai"];
//$id_device = $_POST["id_device"];
//$id_pegawai = "111112";
//$id_device = "d9914a1bf2f48509x";
$mysql_qry_cek = "select id_device from pegawai where id_pegawai like '$id_pegawai'";
$result_cek = mysqli_query($conn, $mysql_qry_cek);
if (mysqli_num_rows($result_cek)>0) {
	$row = mysqli_fetch_row ($result_cek);
	if ($row[0]!=""){
	    //echo $row[0]; 
	    echo "User Sudah Terasosiasi";
	}
	else {
	    $mysql_qry = "select * from pegawai where id_pegawai like '$id_pegawai'";
        $result = mysqli_query($conn, $mysql_qry);
        if (mysqli_num_rows($result)>0) {
            $row = mysqli_fetch_assoc ($result);

            $id = $id_pegawai;
            $mysql_qry_data = "select * from pegawai where id_pegawai like '$id'";
            $result_data = mysqli_query($conn, $mysql_qry_data);
	        $hasil_data = array();

            while ($row = mysqli_fetch_array($result_data)) {
                array_push ($hasil_data, array("id"=>$row[0], "nama_pegawai"=>$row[1], "lat_kantor"=>$row[2], "lon_kantor"=>$row[3], "id_device"=>$row[4], "status"=>$row[5]));
            }
    
            echo json_encode(array("hasil data"=>$hasil_data));
    

        }
        else {
	        echo "No Pegawai Tidak Dikenal";
        }
	    
	}
}
else {
/*
    $mysql_qry = "select * from pegawai where id_pegawai like '$id_pegawai'";
    $result = mysqli_query($conn, $mysql_qry);
    if (mysqli_num_rows($result)>0) {
        $row = mysqli_fetch_assoc ($result);

        $id = $id_pegawai;
        $mysql_qry_data = "select * from pegawai where id_pegawai like '$id'";
        $result_data = mysqli_query($conn, $mysql_qry_data);
	    $hasil_data = array();

        while ($row = mysqli_fetch_array($result_data)) {
            array_push ($hasil_data, array("id"=>$row[0], "nama_pegawai"=>$row[1], "lat_kantor"=>$row[2], "lon_kantor"=>$row[3], "id_device"=>$row[4], "status"=>$row[5]));
        }
    
        echo json_encode(array("hasil data"=>$hasil_data));
    

    }
    else {
	    echo "No Pegawai Tidak Dikenal";
    }
*/
echo "No Pegawai Tidak Dikenal";
}
$conn->close();
?>